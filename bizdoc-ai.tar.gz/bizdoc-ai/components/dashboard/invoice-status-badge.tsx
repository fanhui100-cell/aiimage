'use client'

import { useState } from 'react'

type InvoiceStatus = 'pending' | 'paid' | 'overdue'

const STATUS_STYLES: Record<InvoiceStatus, string> = {
  pending:  'bg-yellow-50 text-yellow-700 border-yellow-200',
  paid:     'bg-green-50  text-green-700  border-green-200',
  overdue:  'bg-red-50    text-red-700    border-red-200',
}

const STATUS_LABELS: Record<InvoiceStatus, { zh: string; en: string }> = {
  pending: { zh: '待支付', en: 'Pending' },
  paid:    { zh: '已支付', en: 'Paid' },
  overdue: { zh: '已逾期', en: 'Overdue' },
}

const CYCLE: Record<InvoiceStatus, InvoiceStatus> = {
  pending: 'paid',
  paid:    'overdue',
  overdue: 'pending',
}

interface Props {
  genId: string
  initialStatus: InvoiceStatus | null
  zh: boolean
}

export function InvoiceStatusBadge({ genId, initialStatus, zh }: Props) {
  const [status, setStatus] = useState<InvoiceStatus>(initialStatus ?? 'pending')
  const [saving, setSaving] = useState(false)

  const cycle = async () => {
    const next = CYCLE[status]
    setSaving(true)
    try {
      await fetch(`/api/generations/${genId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ invoiceStatus: next }),
      })
      setStatus(next)
    } finally {
      setSaving(false)
    }
  }

  return (
    <button
      onClick={cycle}
      disabled={saving}
      title={zh ? '点击切换状态' : 'Click to change status'}
      className={`text-xs border rounded-full px-2 py-0.5 font-medium transition-opacity disabled:opacity-50 ${STATUS_STYLES[status]}`}
    >
      {STATUS_LABELS[status][zh ? 'zh' : 'en']}
    </button>
  )
}
